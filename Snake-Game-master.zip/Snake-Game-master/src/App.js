import './App.css';
import Board from './Board/Board.jsx';

function App() {
  return (
    <div className="App">
      <Board/>
    </div>
  );
}

export default App;
